 

 Certain portions of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General Public
License  version  2  (GPLv2)  with   the  Classpath  Exception  (http://
openjdk.java.net/legal/gplv2+ce.html).  For a period of three years from
the date  of your receipt  of  this  software,  Azul  will  provide upon
request, a complete  machine readable  copy of the  source code for such
portions  based  on  OpenJDK on a medium  customarily used  for software
interchange for a charge no more  than the cost of physically performing
source distribution.


  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  zsrc8.46.0.19-jdk8.0.252 988bece3cedfa22baafb27dbfbae254a3af8e193190f5ebd9ab7224ca4e107fe917f277d189ce40233f00906faa6754dbb7678c07520ad13260288a45e3189490c24de593b65725012b18169b9b76bf6aec3834cb53b5372096aa4e13f71c11c46396be0e8b960fcd755d15ec2380feca26228daeb341bdaf5d484bd6ecabf39d959da1aae1daf5d3a5bed468ecd93130ef646ad42ea0dcc347022c6e8e17e03
  OpenJSSE 1.1.3 2976fabcaff95dea6a34f1636c1cc6416a880dc8

